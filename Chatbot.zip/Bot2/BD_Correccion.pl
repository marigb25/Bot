	% Prolog File

% Lee base anterior de no entendi

:-consult('noent').

%base de conocimientos
%base(tema,subtema,pregunta,respuesta)

encoding(utf8).
%set_stream(user_input,encoding(utf8)).
%set_stream(user_output,encoding(utf8)).


%Preguntas
preguntas(cs,"¿cuales son?").
preguntas(cf,"¿como funciona?").
preguntas(csu,"¿cuando se usan?").
preguntas(qth,"¿que tipo hay?").
preguntas(qs,"¿que es?").
preguntas(tdsi,"tengo dudas sobre los indices").
preguntas(mc,"mi se cicla").
preguntas(nejp,"necesito un ejemplo del").
preguntas(ccdu,"¿cual es el cuerpo de un?").
preguntas(phm,"puede haber mas de un").
preguntas(pqs,"¿para que sirve?").
preguntas(cu,"¿cuando uso?").
preguntas(cr,"¿como recorro?").
preguntas(csr,"¿como se recorre?").
preguntas(ccr,"¿como comparar?").
preguntas(cc,"¿como comparo?").
preguntas(csc,"¿como se compara?").
preguntas(ci,"¿como imprimo?").
preguntas(cd,"¿como declaro?").
preguntas(cdr,"¿como declarar?").
preguntas(csd,"¿como se declara?").
preguntas(cde,"¿cual es la diferencia entre?").
preguntas(csiv,"¿como se imprimen los valores de?").
preguntas(civ,"¿como imprimo los valores de?").
preguntas(aqr,"a que se refiere con").
preguntas(cdu,"¿cuando usar?").
preguntas(cld,"¿cual es la diferencia?").
preguntas(ch,"¿como se hace?").
preguntas(rps,"me puedes dar un repaso").
preguntas(dejp,"dame un ejemplo").
preguntas(nejp,"necesito un ejemplo").
preguntas(mejp,"me puedes ayudar con un ejemplo").

 %Base

%Preguntas sobre paso de parametros
base(parametro,"parametro",qs,"Es una variable utilizada para recibir valores de entrada en una rutina, subrutina o método").
base(parametro,"parametro",cs,"Hay 2 tipos de paso de parametro: el paso por referencia y el paso por valor").
base(parametro,"parametro",pqs,"Para recibir valores de entrada en una rutina, subrutina o método.").
base(parametro,"parametro",cf,"El paso de valor consiste en copiar el contenido de la memoria del argumento que se quiere pasar a otra dirección de memoria, se tendrán dos valores duplicados e independientes, con lo que la modificación de uno no afecta al otro.Así como por referencia en el cual se manda la direccion de memoria del atributo original, en el cual si se modifica uno afecta al otro.").
base(parametro,"parametro",cu,"Sí deseas tener dos argumentos independientes en el cual uno no afecte al otro el paso por valor es el requerido, de lo contrario se usa el paso por referencia.").
base(parametro,"parametro",qth,"hay 2 tipos de paso de parametro, el paso por referencia y el paso por valor").

base(parametro,"valor",pqs,"Esta forma nos dice que nuestra función recibirá una copia de la variable que pasemos y, cualquier modificación que realicemos, solo afectará a dicha copia.").
base(parametro,"valor",cf,"El paso de valor consiste en copiar el contenido de la memoria del argumento que se quiere pasar a otra dirección de memoria, se tendrán dos valores duplicados e independientes, con lo que la modificación de uno no afecta al otro.").
base(parametro,"valor",cu,"Sí necesitas tener dos argumentos independientes en el cual al modificar uno no afecte al otro el paso por valor es el requerido").

base(parametro,"referencia",pqs,"Esta forma se nos lleva a entregar prácticamente la variable original, es decir, si realizamos algún cambio en el parámetro de nuestra función, esto equivaldría a estar actuando directamente sobre la variable original.").
base(parametro,"referencia",cf,"Por referencia en el cual se manda la direccion de memoria del atributo original, en el cual si se modifica uno afecta al otro.").
base(parametro,"referencia",cu,"Sí necesitas tener dos argumentos los cuales apunten a la misma direccion de memoria, lo cúal implica que al modificar uno se ve reflejado en el otro argumento").



%Preguntas sobre estructuras de control
base(estructuras,"estructura",qs,"Se denominan estructuras de control a aquellas que determinan que instrucciones deben ejecutarse y que número de veces").
base(estructuras,"estructura",cs,"Existen dos tipos de estructuras de control: alternativas o de selección y las repetitivas o de iteración").
base(estructuras,"estructura",qth,"Existen dos tipos de estructuras de control: alternativas o de selección y las repetitivas o de iteración").
base(estructuras,"estructura",cf,"Las estructuras de control permiten modificar el flujo de ejecución de las instrucciones de un programa").
base(estructuras,"if",cf,"Primero se evalúa la condicion. Si el resultado se cumple, se ejecutará el código. Si el resultado no es true, el programa continúa con la sentencia siguiente.").
base(estructuras,"for",cf,"Las instrucciones se repiten el número de veces que le decimos, normalmente le ponemos un número ( o el valor de una variable o una ").
base(estructuras,"while",cf,"Se va repitiendo el código en base a una condicion, es decir, mientras esa condición sea verdadera").
base(estructuras,"do-while",cf,"Primero se ejecuta el bloque de instrucciones y, después, se evalúa la condición. En el caso de que ésta sea verdadera, se vuelve a ejecutar el bloque de instrucciones. Y así sucesivamente, hasta que, la condición sea falsa").
base(estructuras,"if",qs,"Tipo de estructura de seleccion empleada en la programación de algoritmos").
base(estructuras,"for",qs,"Es una estructura de repetición empleada en la programación de algoritmos para repetir un código una o más veces dependiendo de un contador").
base(estructuras,"while",qs,"Es una estructura de repetición empleada en la programacion de algoritmos permite al programador especificar las veces que se repita una acción (una o más sentencias)").
base(estructuras,"do-while",qs,"Es un tipo de estructura repetitiva eficiente. Lo que lo diferencia con el while es que la condición se evalúa al finalizar el ciclo, esto hace que las instrucciones se ejecuten cuando menos una vez").
base(estructuras,"for",tdsi,"El índice comienza donde el programador diga , esto quiere decir que puede iniciar en 0 ó en 1 ó 2 ... etc de igual forma el for puede ir hacia delante o hacia atrás, hablando del incremento").
base(estructuras,"while",tdsi,"Los índices del while están dados por alguna variable que se incrementa en 1 cada que se repite el ciclo").
base(estructuras,"do-while",tdsi,"Los índices del do-while están dados por alguna variable que se incrementa en 1 cada que se repite el ciclo").
base(estructuras,"for",mc,"Tienes que revisar los indices de tu for puede que estés pasando por alto algo.").
base(estructuras,"while",mc,"Tal vez olvidaste el contador, que ayuda a detener el ciclo ó la condición está mal").
base(estructuras,"do-while",mc,"Tienes que revisar los parámetros de tu do-while puede que te hayas olvidado del incremento que lleva el do-while").
base(estructuras,"if",nejp,"El ejemplo te muestra cómo se decidirá qué camino tomará el programa dependiendo si se cumple o no la condición. file:///./imagenes/ejemplo_if.png").
base(estructuras,"for",nejp,"La imagen muestra como es la estructura de for y cuales son los parámetros del mismo. file:///./imagenes/ejemplo_for.png ").
base(estructuras,"while",nejp,"La imagen muestra como es la estructura de while y cual es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_while.png ").
base(estructuras,"do-while",nejp,"La imagen muestra como es la estructura de do-while y cuál es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_do_while.png ").
base(estructuras,"if",dejp,"El ejemplo te muestra cómo se decidirá qué camino tomará el programa dependiendo si se cumple o no la condición. file:///./imagenes/ejemplo_if.png").
base(estructuras,"for",dejp,"La imagen muestra como es la estructura de for y cuales son los parámetros del mismo. file:///./imagenes/ejemplo_for.png ").
base(estructuras,"while",dejp,"La imagen muestra como es la estructura de while y cual es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_while.png ").
base(estructuras,"do-while",dejp,"La imagen muestra como es la estructura de do-while y cuál es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_do_while.png ").
base(estructuras,"if",mejp,"El ejemplo te muestra cómo se decidirá qué camino tomará el programa dependiendo si se cumple o no la condición. file:///./imagenes/ejemplo_if.png").
base(estructuras,"for",mejp,"La imagen muestra como es la estructura de for y cuales son los parámetros del mismo. file:///./imagenes/ejemplo_for.png ").
base(estructuras,"while",mejp,"La imagen muestra como es la estructura de while y cual es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_while.png ").
base(estructuras,"do-while",mejp,"La imagen muestra como es la estructura de do-while y cuál es la condición que se debe cumplir para que se repita el ciclo. file:///./imagenes/ejemplo_do_while.png ").
base(estructuras,"if",ccdu,"El cuerpo del if es: file:///./imagenes/cuerpo_if.png ").
base(estructuras,"for",ccdu,"El cuerpo del for es: file:///./imagenes/cuerpo_for.png ").
base(estructuras,"while",ccdu,"El cuerpo del while es : file:///./imagenes/cuerpo_while.png ").
base(estructuras,"do-while",ccdu,"El cuerpo del do-while: file:///./imagenes/cuerpo_do_while.png ").
base(estructuras,"if",cd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_if.png ").
base(estructuras,"for",cd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_for.png ").
base(estructuras,"while",cd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_while.png ").
base(estructuras,"do-while",cd,"Se declara de la siguiente manera:  file:///./imagenes/cuerpo_do_while.png ").
base(estructuras,"if",cdr,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_if.png ").
base(estructuras,"for",cdr,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_for.png ").
base(estructuras,"while",cdr,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_while.png ").
base(estructuras,"do-while",cdr,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_do_while.png ").
base(estructuras,"if",csd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_if.png ").
base(estructuras,"for",csd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_for.png ").
base(estructuras,"while",csd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_while.png ").
base(estructuras,"do-while",csd,"Se declara de la siguiente manera: file:///./imagenes/cuerpo_do_while.png ").
base(estructuras,"if",phm,"Si puede,es sentencia if anidada, se puede utilizar para implementar decisiones con varias alternativas o multi-alternativas").
base(estructuras,"for",phm,"Claro que sí puede haber ciclos for anidados pero mientras más haya, más será el gasto computacional.").
base(estructuras,"while",phm,"Claro que sí puede haber ciclos while anidados pero mientras más haya, más será el gasto computacional").
base(estructuras,"do-while",phm,"Claro que sí puede haber ciclos do-while anidados pero mientras más haya más será el gasto computacional.").
base(estructuras,"do-while",cde,"La diferencia radica en que el bucle DO WHILE opera la condición luego de realizar las sentencias que se encuentran dentro del ciclo MIENTRAS esto quiere decir que se ejecutara al menos una vez"). 
base(estructuras,"while",cde,"La diferencia radica en que el bucle DO WHILE opera la condición luego de realizar las sentencias que se encuentran dentro del ciclo MIENTRAS esto quiere decir que se ejecutara al menos una vez"). 
 
 
 
%preguntas sobre estructura de datos
base(datos,"estructura",qs,"Es una forma particular de organizar datos en una computadora para que puedan ser utilizados de manera eficiente.").
base(datos,"arreglo",qs,"Es una colección de objetos numerados del mismo tipo, en donde cada variable o celda en el arreglo tiene un índice. Las celdas están numeradas del 0 al N-1, donde N es el número de celdas del arreglo es decir su capacidad.").
base(datos,"arreglo",cs,"Hay 2 tipos de arreglos,los unidimensionales y los multidimensionales.").
base(datos,"arreglo",qth,"Hay 2 tipos de arreglos,los unidimensionales y los multidimensionales.").
base(datos,"vector",qs,"Es un arreglo de “N” elementos organizados en una dimensión donde “N” recibe el nombre de longitud o tamaño del vector.").
base(datos,"matriz",qs,"Es un arreglo de M * N elementos organizados en dos dimensiones donde “M” es el numero de filas o reglones y “N” el numero de columnas.").


base(datos,"arreglo",cd,"Los arreglos (arrays) son variables del mismo tipo de dato que tienen el mismo nombre y que se distinguen y referencian por un índice. Sintaxis: file:///./imagenes/sintaxis_arreglo.png ").
base(datos,"arreglo",cdr,"Los arreglos (arrays) son variables del mismo tipo de dato que tienen el mismo nombre y que se distinguen y referencian por un índice. Sintaxis: file:///./imagenes/sintaxis_arreglo.png ").
base(datos,"arreglo",csd,"Los arreglos (arrays) son variables del mismo tipo de dato que tienen el mismo nombre y que se distinguen y referencian por un índice. Sintaxis: file:///./imagenes/sintaxis_arreglo.png ").
base(datos,"matriz",cd,"Para representar una matriz se necesita un nombre de matriz acompañado de dos índices. Sintaxis: file:///./imagenes/sintaxis_matriz.png ").
base(datos,"matriz",cdr,"Para representar una matriz se necesita un nombre de matriz acompañado de dos índices. Sintaxis: file:///./imagenes/sintaxis_matriz.png ").
base(datos,"matriz",csd,"Para representar una matriz se necesita un nombre de matriz acompañado de dos índices. Sintaxis: file:///./imagenes/sintaxis_matriz.png ").
base(datos,"arreglo",pqs,"Un arreglo sirve para almacenar datos de cierto tipo como números enteros, flotantes, caracteres, etc.").
base(datos,"arreglo",csu,"Un arreglo lo usas cuando quieres guardar muchos datos de un mismo tipo para usarlos más adelante.").
base(datos,"arreglo",cu,"Un arreglo lo usas cuando quieres guardar muchos datos de un mismo tipo para usarlos más adelante.").
base(datos,"arreglo",cde,"Ambas son estructuras de datos estáticas, o sea, que separan memoria física para almacenar datos y que no puede ser modificada en tiempo de ejecución. La diferencia estriba en la manera de acceder a dichas estructuras, mientras los arreglos son accedidos con un subíndice, las matrices usan dos subíndices. En el momento de crear una matriz, la memoria central, separa espacio en posiciones consecutivas que gráficamente representan casillas de filas y columnas.").
base(datos,"matriz",pqs,"Una matriz sirve para guardar datos de un mismo tipo en una forma ordenada con el fin de usarlos posteriormente o simplemente mostrarlos.").
base(datos,"matriz",csu,"Una matriz la usas cuando quieres guardar una gran cantidad de datos de un mismo tipo.").
base(datos,"matriz",cu,"Una matriz la usas cuando quieres guardar una gran cantidad de datos de un mismo tipo.").
base(datos,"matriz",cde,"Ambas son estructuras de datos estáticas, o sea, que separan <mem></mem>oria física para almacenar datos y que no puede ser modificada en tiempo de ejecución. La diferencia estriba en la manera de acceder a dichas estructuras, mientras los arreglos son accedidos con un subíndice, las matrices usan dos subíndices. En el momento de crear una matriz, la memoria central, separa espacio en posiciones consecutivas que gráficamente representan casillas de filas y columnas.").
base(datos,"arreglo",cr,"Para recorrer un arreglo se hace uso de un ciclo for el cual va a iterar desde la primer posición del arreglo hasta la última, recordando que las posiciones de un arreglo van de la cero a la n-1, es decir, si tenemos un arreglo de 4 elementos nuestro for va a iterar desde el 0 hasta el 3. Ejemplo file:///./imagenes/ejemplo_for_arreglo.png ").
base(datos,"arreglo",csr,"Para recorrer un arreglo se hace uso de un ciclo for el cual va a iterar desde la primer posición del arreglo hasta la última, recordando que las posiciones de un arreglo van de la cero a la n-1, es decir, si tenemos un arreglo de 4 elementos nuestro for va a iterar desde el 0 hasta el 3. Ejemplo file:///./imagenes/ejemplo_for_arreglo.png ").
base(datos,"arreglo",cc,"Para comparar las posiciones de un arreglo estos se tienen que recorrer posición a posición, por ejemplo si se tienen 2 arreglos de enteros y se quiere saber cuántos números iguales están en la misma posición de ambos arreglos se haría lo siguiente. En este ejemplo si un número existente en la posición i en el arreglo a es igual a un número existente en la posición i del arreglo b se aumenta un contador, al finalizar el for se imprime el número de coincidencias (cont) de número entre los 2 arreglos. file:///./imagenes/ejemplo_for_matriz.png ").
base(datos,"arreglo",ccr,"Para comparar las posiciones de un arreglo estos se tienen que recorrer posición a posición, por ejemplo si se tienen 2 arreglos de enteros y se quiere saber cuántos números iguales están en la misma posición de ambos arreglos se haría lo siguiente. En este ejemplo si un número existente en la posición i en el arreglo a es igual a un número existente en la posición i del arreglo b se aumenta un contador, al finalizar el for se imprime el número de coincidencias (cont) de número entre los 2 arreglos. file:///./imagenes/ejemplo_for_matriz.png ").
base(datos,"arreglo",csc,"Para comparar las posiciones de un arreglo estos se tienen que recorrer posición a posición, por ejemplo si se tienen 2 arreglos de enteros y se quiere saber cuántos números iguales están en la misma posición de ambos arreglos se haría lo siguiente. En este ejemplo si un número existente en la posición i en el arreglo a es igual a un número existente en la posición i del arreglo b se aumenta un contador, al finalizar el for se imprime el número de coincidencias (cont) de número entre los 2 arreglos. file:///./imagenes/ejemplo_for_matriz.png ").
base(datos,"arreglo",ci,"Para imprimir los valores de un arreglo este se tiene que ir recorriendo posición por posición para escribir en pantalla lo que tiene dicho arreglo. En este caso para cada posición del arreglo (i) se va a escribir el mensaje que está dentro del ciclo. file:///./imagenes/imprime_arreglo.png ").
base(datos,"arreglo",csiv,"Para imprimir los valores de un arreglo este se tiene que ir recorriendo posición por posición para escribir en pantalla lo que tiene dicho arreglo. En este caso para cada posición del arreglo (i) se va a escribir el mensaje que está dentro del ciclo. file:///./imagenes/imprime_arreglo.png ").
base(datos,"arreglo",civ,"Para imprimir los valores de un arreglo este se tiene que ir recorriendo posición por posición para escribir en pantalla lo que tiene dicho arreglo. En este caso para cada posición del arreglo (i) se va a escribir el mensaje que está dentro del ciclo. file:///./imagenes/imprime_arreglo.png ").
base(datos,"matriz",cr,"Para recorrer una matriz se debe hacer uso de dos ciclos for uno para que recorra las filas y otro anidado a este primero que recorra las columnas. En este caso el primer for va a ir de la posición 0 hasta el número de filas que tenga nuestra matriz (f). Por otra parte el segundo for irá desde la posición cero hasta el número de columnas que contenga nuestra matriz (c). En conclusión, por cada fila de nuestra matriz (primer for) va a ir recorriendo las columnas (segundo for). file:///./imagenes/recorre_matriz.png ").
base(datos,"matriz",csr,"Para recorrer una matriz se debe hacer uso de dos ciclos for uno para que recorra las filas y otro anidado a este primero que recorra las columnas. En este caso el primer for va a ir de la posición 0 hasta el número de filas que tenga nuestra matriz (f). Por otra parte el segundo for irá desde la posición cero hasta el número de columnas que contenga nuestra matriz (c). En conclusión, por cada fila de nuestra matriz (primer for) va a ir recorriendo las columnas (segundo for). file:///./imagenes/recorre_matriz.png ").
base(datos,"matriz",cc,"Para comparar 2 matrices se tiene que hacer uso de dos ciclos for para recorrerlas. Por ejemplo si se quiere saber si una matriz a es exactamente igual a una matriz b ambas de números enteros y de la misma dimension (mismo número de filas y columnas) se haría lo siguiente. En este caso si al recorrer las matrices encuentra en alguna posición (i,j) que el dato contenido en dicha posición en la matriz a es diferente al contenido en la posición de la matriz b al finalizar el recorrido nos dirá que las matrices no son iguales. file:///./imagenes/compara_matriz.png ").
base(datos,"matriz",ccr,"Para comparar 2 matrices se tiene que hacer uso de dos ciclos for para recorrerlas. Por ejemplo si se quiere saber si una matriz a es exactamente igual a una matriz b ambas de números enteros y de la misma dimension (mismo número de filas y columnas) se haría lo siguiente. En este caso si al recorrer las matrices encuentra en alguna posición (i,j) que el dato contenido en dicha posición en la matriz a es diferente al contenido en la posición de la matriz b al finalizar el recorrido nos dirá que las matrices no son iguales. file:///./imagenes/compara_matriz.png ").
base(datos,"matriz",csc,"Para comparar 2 matrices se tiene que hacer uso de dos ciclos for para recorrerlas. Por ejemplo si se quiere saber si una matriz a es exactamente igual a una matriz b ambas de números enteros y de la misma dimension (mismo número de filas y columnas) se haría lo siguiente. En este caso si al recorrer las matrices encuentra en alguna posición (i,j) que el dato contenido en dicha posición en la matriz a es diferente al contenido en la posición de la matriz b al finalizar el recorrido nos dirá que las matrices no son iguales. file:///./imagenes/compara_matriz.png ").

base(datos,"matriz",ci,"Para poder imprimir los valores que contiene una matriz esta se tiene que recorrer posición a posición e imprimir en pantalla el valor de la siguiente forma. file:///./imagenes/imprime_matriz.png ").
base(datos,"matriz",csiv,"Para poder imprimir los valores que contiene una matriz esta se tiene que recorrer posición a posición e imprimir en pantalla el valor de la siguiente forma. file:///./imagenes/imprime_matriz.png ").
base(datos,"matriz",civ,"Para poder imprimir los valores que contiene una matriz esta se tiene que recorrer posición a posición e imprimir en pantalla el valor de la siguiente forma. file:///./imagenes/imprime_matriz.png ").

%Preguntas sobre otros(librerias,depurar,entradas,salidas)

base(otro,"libreria",cf,"El compilador puede leer el archivo(librería), en él encuentra las instrucciones de uso de muchos y distintos métodos y funciones.").
base(otro,"entrda",qs,"Los datos de entrada son los que la computadora va a procesar.").
base(otro,"salida",qs,"Los datos de salida son datos derivados, es decir, obtenidos a partir de los datos de entrada.").
base(otro,"libreria",qs,"Una librería es un archivo o conjunto de archivos que se utilizan para facilitar la programación.").
base(otro,"depurar",qs,"La depuración de un programa es la forma de saber si un programa contiene errores o no, así mismo también nos ayuda a corregir dichos errores.").
base(otro,"entrda",aqr,"Se refiere a las señales electrónicas que son enviadas hacia un destino de ingreso determinado, para su debido procesamiento.").
base(otro,"salida",aqr,"Se refiere a las señales que han sido procesadas, y que se envían hacia un dispositivo específico, para poder ser interpretados por el usuario.").
base(otro,"libreria",aqr,"Se refiere a los archivos que contienen instrucciones de métodos y funciones.").
base(otro,"depurar",aqr,"Se refiere a que puedes verificar en qué parte de tu programa te estás equivocando.").
base(otro,"entrda",pqs,"Los datos de entrada nos sirven para que realicen una acción determinada.").
base(otro,"salida",pqs,"Los datos de salida sirven para que el usuario fácilmente veo sus resultados, los cuales tendremos la posibilidad de que estos datos puedan ser vistos, leídos e interpretados mediante nuestros sentidos.").
base(otro,"libreria",pqs,"Las librerías nos sirven para facilitar su propio trabajo, y que puede incluir en cualquier página cuando lo necesite").
base(otro,"depurar",pqs,"Depurar un programa te sirve a solucionar los posibles errores encontrados.").
base(otro,"entrda",cdu,"Cuando el usuario quiera ingresar un dato dentro al sistema").
base(otro,"libreria",cdu,"Cuando queramos facilitar la programación, ya que nos permite la abstracción haciendo que nuestro programa sea más sencillo de hacer y de entender.").
base(otro,"entrda",cld,"Los datos de entrada se les considera la materia prima de los datos de salida, considerados estos como la verdadera información.").
base(otro,"libreria",ch,"Una librería se hace a base de instrucciones de uso de muchos y distintos métodos y funciones").
base(otro,"depurar",ch,"Tenemos que colocar algún punto de parada en la parte del programa que queremos depurar. Los puntos de parada indican al depurador que detenga la ejecución del programa y devuelvan el control al usuario, es decir, a nosotros. Una vez detenido el programa podremos inspeccionar variables, modificarlas, continuar la ejecución, o seguir ejecutando el programa sentencia a sentencia.").
base(otro,"depurar",cs,"Primero colocar algún punto de parada en la parte del programa que queremos depurar. Los puntos de parada indican al depurador que detenga la ejecución del programa y devuelvan el control al usuario, es decir, a nosotros. Una vez detenido el programa podremos inspeccionar variables, modificarlas, continuar la ejecución, o seguir ejecutando el programa sentencia a sentencia. Segundo seguir hasta ya no tener errores.").
base(otro,"libreria",csu,"Cuando queramos facilitar la programación, ya que nos permite la abstracción haciendo que nuestro programa sea más sencillo de hacer y de entender.").
base(otro,"entrda",cu,"Cuando el usuario quiera ingresar un dato dentro al sistema").
base(otro,"libreria",cu,"Cuando queramos facilitar la programación, ya que nos permite la abstracción haciendo que nuestro programa sea más sencillo de hacer y de entender.").
base(otro,"entrda",rps,"Se refiere a las operaciones que se producen en el teclado y en la pantalla de lacomputadora. En C no hay palabras claves para realizar las acciones de Entrada/Salida,estas se hacen mediante el uso de las funciones de la biblioteca estándar (stadio.h).Para utilizar las funciones de E / S debemos incluir en el programa el archivo de cabecera.").
base(otro,"salida",rps,"Se refiere a las operaciones que se producen en el teclado y en la pantalla de lacomputadora. En C no hay palabras claves para realizar las acciones de Entrada/Salida,estas se hacen mediante el uso de las funciones de la biblioteca estándar (stadio.h).Para utilizar las funciones de E / S debemos incluir en el programa el archivo de cabecera").
base(otro,"libreria",rps,"Una librería es un conjunto de recursos (algoritmos) prefabricados, que pueden ser utilizados por el programador para realizar determinadas operaciones. Las declaraciones de las funciones utilizadas en estas librerías, junto con algunas macros y constantes predefinidas que facilitan su utilización, se agrupan en ficheros de nombres conocidos que suelen encontrarse en sitios predefinidos. Por ejemplo, en los sistemas UNIX,
en  /usr/include. Estos ficheros se suelen llamar “de cabecera”, porque es tradición utilizar las primeras líneas del programa para poner las directivas #include que los incluirá en el fuente durante la fase de preprocesado.").
base(otro,"depurar",rps,"La depuración de programas es el proceso de identificar y corregir errores de programación. En inglés se conoce como debugging, porque se asemeja a la eliminación de bichos (bugs), manera en que se conoce informalmente a los errores de programación.").
base(otro,"entrda",dejp,"La función scanf() es, en muchos sentidos, la inversa de printf(). Puede leer desde el dispositivo de entrada estándar (normalmente el teclado) datos de cualquier tipo de los manejados por el compilador, convirtiéndolos al formato interno apropiado
Por ejemplo: file:///./imagenes/ejemplo_entrada.png ").
base(otro,"salida",dejp,"La función printf() (de 'print' = imprimir y 'f' = formato) sirve para escribir datos en el dispositivo de salida estándar (generalmente la pantalla) con un formato determinado por el programador. file:///./imagenes/ejemplo_salida.png ").

base(otro,"libreria",dejp,"La declaración de librerías, tanto en C, se debe hacer al principio de todo nuestro código, antes de la declaración de cualquier función o línea de código, debemos indicarle al compilador que librerías usar, para el saber qué términos están correctos en la escritura de nuestro código y cuáles no. La sintaxis es la siguiente:
 #include <nombre de la librería> o
alternativamente #include <nombre de la librería>.
Ejemplo: file:///./imagenes/ejemplo_libreria.png ").

base(otro,"depurar",dejp,"Si trabajamos con DevC++ para Windows.
1.Primero debemos indicar dónde queremos que se interrumpa el programa (añadir un “breakpoint”), haciendo clic con el ratón en el margen izquierdo de nuestro programa. Esa línea quedará resaltada en color rojo.
2.Ahora ponemos en marcha el programa desde el menú “Depurar”.
3.En la parte inferior de la pantalla aparecerán botones que nos permiten avanzar paso a paso, saltar las funciones o añadir un
“watch” para comprobar el valor de una variables. La línea que estamos depurando se marcará en azul (y destacada con una flecha).
 Los “watches” estarán visibles en la parte izquierda de la pantalla.").

base(otro,"entrda",nejp,"La función scanf() es, en muchos sentidos, la inversa de printf(). Puede leer desde el dispositivo de entrada estándar (normalmente el teclado) datos de cualquier tipo de los
manejados por el compilador, convirtiéndolos al formato interno apropiado
Por ejemplo: file:///./imagenes/ejemplo_entrada.png ").
base(otro,"salida",nejp,"La función printf() (de 'print' = imprimir y 'f' = formato) sirve para escribir datos en el dispositivo de salida estándar (generalmente la pantalla) con un formato determinado por el programador. file:///./imagenes/ejemplo_salida.png ").
base(otro,"libreria",nejp,"La declaración de librerías, tanto en C, se debe hacer al principio de todo nuestro código, antes de la declaración de cualquier función o línea de código, debemos indicarle al compilador que librerías usar, para el saber qué términos están correctos en la escritura de nuestro código y cuáles no. La sintaxis es la siguiente:
 #include <nombre de la librería> o alternativamente #include 'nombre de la librería'.
Ejemplo: file:///./imagenes/ejemplo_libreria.png ").
base(otro,"depurar",nejp,"Si trabajamos con DevC++ para Windows.
1.Primero debemos indicar dónde queremos que se interrumpa el programa (añadir un 'breakpoint'), haciendo clic con el ratón en el margen izquierdo de nuestro programa. Esa línea quedará resaltada en color rojo.
2.Ahora ponemos en marcha el programa desde el menú 'Depurar'.
3.En la parte inferior de la pantalla aparecerán botones que nos permiten avanzar paso a paso, saltar las funciones o añadir un
'watch' para comprobar el valor de una variables. La línea que estamos depurando se marcará en azul (y destacada con una flecha).
Los 'watches' estarán visibles en la parte izquierda de la pantalla.").
base(otro,"entrda",mejp,"La función scanf() es, en muchos sentidos, la inversa de printf(). Puede leer desde el dispositivo de entrada estándar (normalmente el teclado) datos de cualquier tipo de los manejados por el compilador, convirtiéndolos al formato interno apropiado
Por ejemplo: file:///./imagenes/ejemplo_entrada.png ").
base(otro,"salida",mejp,"La función printf() (de 'print' = imprimir y 'f' = formato) sirve para escribir datos en el dispositivo de salida estándar (generalmente la pantalla) con un formato determinado por el programador. file:///./imagenes/ejemplo_entrada.png ").
base(otro,"libreria",mejp,"La declaración de librerías, tanto en C, se debe hacer al principio de todo nuestro código, antes de la declaración de cualquier función o línea de código, debemos indicarle al compilador que librerías usar, para el saber qué términos están correctos en la escritura de nuestro código y cuáles no. La sintaxis es la siguiente:
 #include <nombre de la librería> o
alternativamente #include 'nombre de la librería'.
Ejemplo: file:///./imagenes/ejemplo_libreria.png ").
base(otro,"depurar",mejp,"Si trabajamos con DevC++ para Windows.
1.Primero debemos indicar dónde queremos que se interrumpa el programa (añadir un “breakpoint”), haciendo clic con el ratón en el margen izquierdo de nuestro programa. Esa línea quedará resaltada en color rojo.
2.Ahora ponemos en marcha el programa desde el menú “Depurar”.
3.En la parte inferior de la pantalla aparecerán botones que nos permiten avanzar paso a paso, saltar las funciones o añadir un “watch” para comprobar el valor de una variables. La línea que estamos depurando se marcará en azul (y destacada con una flecha). Los “watches” estarán visibles en la parte izquierda de la pantalla.").

%preguntas relacionadas a lectura de archivos
base(otro,"fichero",csu,"Cuando tenemos que guardar los datos de nuestro programa para poderlos recuperar más adelante.").
base(otro,"fichero",cu,"Cuando tenemos que guardar los datos de nuestro programa para poderlos recuperar más adelante.").
base(otro,"fichero",qs,"Es un fichero almacenado en algún recurso de memoria, generalmente en Disco Duro, pero dependiendo del uso son almacenados en RAM. ").
base(otro,"fichero",cs,"Para escritura los tipos de archivos son de texto: txt, doc, docx, etc.De archivo comprimido: zip, rar, tar, etc.",nl,"Para lectura los tipos de archivos son: pdf, epub, azw, ibook, etc.").

base(otro,"archivo",csu,"Cuando tenemos que guardar los datos de nuestro programa para poderlos recuperar más adelante.").
base(otro,"archivo",cu,"Cuando tenemos que guardar los datos de nuestro programa para poderlos recuperar más adelante.").
base(otro,"archivo",qs,"Es un fichero almacenado en algún recurso de memoria, generalmente en Disco Duro, pero dependiendo del uso son almacenados en RAM. ").
base(otro,"archivo",cs,"Para escritura los tipos de archivos son de texto: txt, doc, docx, etc.De archivo comprimido: zip, rar, tar, etc.",nl,"Para lectura los tipos de archivos son: pdf, epub, azw, ibook, etc.").




%Apuntadores
base(datos,"apuntador",qs,"Es un tipo de datos cuyo valor es una dirección de memoria.").
base(datos,"apuntador",cd,"Se declara de la siguiente manera: int *x en caso de que sea de tipo entero.").
base(datos,"apuntador",cdr,"Se declara de la siguiente manera: int *x en caso de que sea de tipo entero.").
base(datos,"apuntador",csd,"Se declara de la siguiente manera: int *x en caso de que sea de tipo entero.").




aparea(T, P, Ti, A):-
    preguntas(Ti, P),
    split_string(P," ","¿?", L1),
    split_string(T," ","¿?", L2),
    igualdad(L2,L1,A).
    
    
busca(B,R):-aparea(B,_,Ti,A),
			member(X,A),
			parecido(X,P),
			base(Tb,P,Ti,R). 
busca(B,_):-write('Lo siento no entiendo tu pregunta. Puedes estructurarla mejor'),
            open('noent.pl',write,S),
            assert(no_entendi(B)),
            set_output(S),
            listing(no_entendi/1),
            close(S).
            
            	
          

parecido(X,X).
parecido("librerias","libreria").
parecido("matrices","matriz").
parecido("arreglos","arreglo").
parecido("depuracion","depurar").
parecido("depura","depurar").
parecido("parametros","parametro").
parecido("do while","do-while").
parecido("dowhile","do-while").
parecido("salidas","salida").
parecido("entradas","entrda").
parecido("entrada","entrda").
parecido("apuntadores","apuntador").
parecido("parametros","parametro")
parecido("archivos","archivo").
parecido("ficheros","fichero").



sinonimo("recorro",["recorre"]).
sinonimo("comparar",["compara","comparo"]).
sinonimo("declarar",["declaro","declara"]).
sinonimo("necesito",["dame","puedes"]).


igualdad(L1,L2,R):-igualdad2(L1,L2,[],R).

% Igualdad(Pregunta,Base,Dife que llevo,Res)
igualdad2(Resto,[],R,Res):-
	append(R,Resto,Res).
igualdad2([L1|LS],[L1|L2],A,R):-
	igualdad2(LS,L2,A,R).
% Veo si hay sinonimos
igualdad2([L1|LS],[L3|L2],A,R):-
	sinonimo(L3,Lista),
	member(L1,Lista),
	igualdad2(LS,L2,A,R).
igualdad2([L1|LS],[L3|L2],A,R):-
	append(A,[L1],NA),
	igualdad2(LS,[L3|L2],NA,R).
	
		
% split_string("hola amigos"," "," ",L).
% preguntas(cs,P1),split_string(P1," "," ",L). pruba con pregunta especifica

% split_string("¿como se complia?"," "," ",L), preguntas(I,P1),split_string(P1," "," ",L1),igualdad(L,L1,R).
% I es cualquier pregunta, verifica si existe.

%preguntaExiste(P,R):-split_string(P," "," ",L1), 
                    % preguntas(I,P1),
                    % split_string(P1," "," ",L2),
                    % igualdad(L1,L2,R).
                     
%preguntaExiste(P,_):-write("no entiendo tu pregunta"),
                    % assert(no_entendi(P)),
                    % listing(no_entendi/1),
                    % open('noent.pl',write,S),set_output(S),                                                                     
                    % listing(no_entendi/1),close(S). 

%append([],L,L).
%append([X|Xs],Ys,[X|Zs]):-append(Xs,Ys,Zs).



 