%%% Recepcion de datos de JavaScript
recibe(JS, P):-
	string_codes(P,JS).
%:- style_check(-singleton).

	
	
respuesta(J):-
	recibe(J,P),
	split_string(P," "," ",L),
	split_string("quien canta A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,artist(F,M),O),
	atomics_to_string(O, ', ', S),
	atom_concat("Lo canta ",S,C),
	write(C).

respuesta(J2):-
	recibe(J2,P),
	split_string(P," "," ",L),
	split_string("en que album sale A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	title(Al,F,H,G),
	atom_concat("En el album ",Al,C),
	write(C).

respuesta(J3):-
	recibe(J3,P),
	split_string(P," "," ",L),
	split_string("que canciones contiene el album A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,title(F,M,H,G),O),
	sort(O,  So),
	atomics_to_string(So, ', ', D),
	write(D).
	
respuesta(J4):-
	recibe(J4,P),
	split_string(P," "," ",L),
	split_string("que cancion canta A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,artist(M,F),O),
	atomics_to_string(O,', ',S),
	atom_concat("Canta ",S,C),
	write(C).
	
respuesta(J5):-
	recibe(J5,P),
	split_string(P," "," ",L),
	split_string("en que album sale A y B"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[NA|AA],[NB|BB]]),
	atomic_list_concat([NA|AA],'_',FA),
	atomic_list_concat([NB|BB],'_',FB),
	title(M,FB,_,_),title(M,FA,_,_),
	atom_concat("Se encuentran en el album ",M,C),
	write(C).

respuesta(J6):-
	recibe(J6,P),
	split_string(P," "," ",L),
	split_string("cual es la cancion numero A del album B"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[NA|AA],[NB|BB]]),
	atomic_list_concat([NA|AA],'_',FA),
	atomic_list_concat([NB|BB],'_',FB),
	atom_number(FA,C),
	title(FB,M,C,_),
	atom_concat("Es ",M,D),
	write(D).

respuesta(J7):-
	recibe(J7,P),
	split_string(P," "," ",L),
	split_string("a que genero pertenece A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,title(_,F,_,M),O),
	atomics_to_string(O,', ',S),
	atom_concat("Es ",S,C),
	write(C).

respuesta(J8):-
	recibe(J8,P),
	split_string(P," "," ",L),
	split_string("cuando se publico el album A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	album(F,M),
	atom_concat("En el ",M,C),
	write(C).
	
respuesta(J9):-
	recibe(J9,P),
	split_string(P," "," ",L),
	split_string("quien es el compositor de A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,composer(F,M),O),
	atomics_to_string(O, ', ', S),
	atom_concat("Es ",S,D),
	write(D).
	
respuesta(JA):-
	recibe(JA,P),
	split_string(P," "," ",L),
	split_string("que comentario tiene A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,comment(F,M),O),
	atomics_to_string(O, ', ', S),
	write(S).

respuesta(JB):-
	recibe(JB,P),
	split_string(P," "," ",L),
	split_string("que canciones ha compuesto A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	findall(M,composer(M,F),O),
	atomics_to_string(O, ', ', S),
	write(S).
	
respuesta(JC):-
	recibe(JC,P),
	split_string(P," "," ",L),
	split_string("que albumes salieron en A"," ", " ", Lp),
	map_string(Lp,Ps),
	map_string(L,Ts),
	match(Ps,Ts,[[N|A]]),
	atomic_list_concat([N|A], '_', F),
	atom_number(F,C),
	%album(M,C),
	findall(M,album(M,C),O),
	atomics_to_string(O,', ',S),
	write(S).
	

%%% Match quien sale con A en B, quien sale con jeff bridges en el big lebowski

match(A, B, R):-
	match(A, B, [], R).

match([], R, A, [Rs]):- % Ya no queda nada
	append(A, R, Rs).
match([X|Xs], [Y|Ys], [], R):- % Mismo texto
	nv(X), X == Y,
	match(Xs, Ys, [], R).
match([X|Xs], [Y|Ys], A, R):- % Mismo texto, re sincroniza
	nv(X), X == Y,
	match(Xs, Ys, [], N),
	append([A], N, R).
match([X|Xs], [Y|Ys], A, Rs):- % Inicia Variable
	v(X),
	match(Xs, Ys, [Y], R),
	append(A,R,Rs).
match([X|Xs], [Y|Ys], A, R):- % Seguimos lo que llevamos
	nv(X),
	append(A, [Y], N),
	match([X|Xs], Ys, N, R).


% utilidad
append([],Ys,Ys).
append([X|Xs],Ys,[X|Zs]):-
	append(Xs,Ys,Zs).
	
map_string([],[]).
map_string([X|Xs],[Y|Ys]):-
	atom_string(Y,X),
	map_string(Xs,Ys).
	
nv(At):-
	atom_chars(At,[A|_]),
	char_type(A,lower).
	
v(At):-
	atom_chars(At,[A|_]),
	char_type(A,upper).
