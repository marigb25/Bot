var path = require('path');


/**
 * La siguiene funcion trata la cadena enviada por prolog, si la cadena incluye un false entonces
 * se nos manda un mensaje diciendo que debemos reescribir la pregunta. En caso contario
 * verifica si nuestra cadena incluye la subcadena "file:///", que identifica a las cadenas 
 * que deben mostrar una imagen. Entonces llama a la funcion cadena simple.
 * En caso contrario nos regresa la cadena limpia es decir sin los caracteres ' R = " " '
 */
function trata_cadena(cadena){
	cadena = cadena+"";
	console.log("valor de cadena"+`${cadena}`);
	if(cadena.includes("entiendo ")){
		var longitud = cadena.length-9;
		var res = cadena.substr(0,longitud);
		return res;
	}else{
		if(cadena.includes("file:///")){
			var cad = cadenaSimple(cadena);
			return cad;
		}else{
			var longitud = cadena.length;
			var res = cadena.substr(4,longitud);
			return res;
		}
	}
}

/**
 * Esta funcion regresa una cadena limpia, es decir busca donde inicia la subcadena "file:///"
 * y nos regresa una subcadena que contiene solo el mensaje que se le mostrara al usuario.
 */

function cadenaSimple(cad){
	cad = cad+"";
	var pos = cad.search("file:///");
	cad = cad.substring(5,pos-1);
	return cad
}

/**
 * La funcion carga imagen recibe la cadena generada por prolog y la trata, si la cadena incluye "file:///"
 * guarda en una variable la subcadena regresada por la funcion "cadenaImagen", en otra variable llamada img
 * se guarda el path de donde esta alojada dicha imagen. Posterior a esto se revisa en que sistema operativo
 * se esta trabajando. Si se esta trabajando en linux o max concatena a nuestra variable img la cadena "file://"
 * una vez obtenida toda la direccion donde se encuentra nuestra imagen se procede a cambiar las "\" por "/" 
 * y se guarda en la variable dir_img  para que el bot nos pueda mostrar la imagen.
 * Si no encontramos en Windows concatena la cadena "file:///" al path obtenido previamente y se procede a cambiar
 * la "\" por "/".
 * En caso de que la cadena mandada no incluya "file:///" se regresa un false. 
 */

function cargaImagen(cadena){
	cadena = cadena+"";
	if(cadena.includes("file:///")){
		var cadI = cadenaImagen(cadena);
		var img = path.resolve(__dirname,cadI);
		var OS = process.platform;
		if(OS.includes("linux") || OS.includes("mac")){
			img = 'file://'+img;
		    var n = cuentaD(img);
		    var imagen = img.split('\\');
		    var dir_img = "";
		    for(i = 0;i <= n; i++){
		    	if (i<n)
		    		dir_img = dir_img + imagen[i]+'/';
		    	else
		    		dir_img = dir_img + imagen[i];
		    }
		}else{
			img = 'file:///'+img;
		    var n = cuentaD(img);
		    var imagen = img.split('\\');
		    var dir_img = "";
		    for(i = 0;i <= n; i++){
		    	if (i<n)
		    		dir_img = dir_img + imagen[i]+'/';
		    	else
		    		dir_img = dir_img + imagen[i];
		    }
		}
	    return dir_img;
	}else{
		return "false";
	}
}

/**
 * Esta funcion cuenta las "\" que tiene el path donde se encuentra nuestra imagen.
 */

function cuentaD(cad){
	var num_repetidos=0;
	for(i = 0;i < cad.length; i++){
		if(cad.charAt(i) == '\\'){
			num_repetidos++;
		}
	}
	return num_repetidos;
}
/**
 * En esta funcion de la cadena obtenida originalmente nos regresa la subcadena que contiene "./imagenes" que es parte
 * de la ruta que se usara para mostrar la imagen seguida de el nombre de nuestra imagen.png
 */
function cadenaImagen(cad){
	var pos = cad.search("./imagenes");
	var pos2 = cad.search(".png");
	var cadI = cad.slice(pos,pos2+4);
	return cadI;
}

exports.trata_cadena = trata_cadena;
exports.cargaImagen = cargaImagen;