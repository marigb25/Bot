:- dynamic no_entendi/1.

no_entendi("como te llamas?").
no_entendi("como defino un apuntador").
no_entendi("varible").
no_entendi("class").
no_entendi("como estas").
no_entendi("hola").
no_entendi("Hola").
no_entendi("que es un fo").
no_entendi("Hola").
no_entendi("dame un ejemplo").
no_entendi("hola").
no_entendi("hola").

