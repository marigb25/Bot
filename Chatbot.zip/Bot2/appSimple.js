// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
/*jshint esversion: 6*/

const { ActivityHandler, ActionTypes, ActivityTypes, CardFactory } = require('botbuilder');
//Copyright (c) Microsoft Corporation. All rights reserved.
//Licensed under the MIT License.

//Alista Prolog
const p = require ('./prolog.js');
const cad = require('./trata_cadena.js');

class EchoBot extends ActivityHandler {
	/**
	   *
	   *@param {ConversationState} conversation state object
	   ** @param {UserState} userState
	   * * @param {Dialog} dialog 
	   */
	     constructor(){
	     super();	 
	     
	    // Creates a new state accessor property.
	    // See https://aka.ms/about-bot-state-accessors to learn more about the bot state and state accessors.
	   this.onMessage(async(context,next)=> {
           await context.sendActivity(`Dijiste '${context.activity.text}'`);
           var query = context.activity.text;
           var data = await p.doQuery(`busca("${query}",R)`);
           var res = cad.trata_cadena(data);
           //await context.sendActivity(`R:${res}'`);
           var img = cad.cargaImagen(data);
           console.log(img);
           const reply = { type: ActivityTypes.Message };
           reply.text = `R:${res}`;
           
          
       if(img.includes("false")){
     //        print("hola");
          }else{
            reply.attachments = ([{
            contentType: 'imagenes/png',
            contentUrl:`${img}`
            }]);
       //      session.send(msg);
          }
		  // await next();
	      await context.sendActivity(reply);
	   });
 


   // Create your bot with a function to receive messages from the user

	   

       this.onMembersAdded(async (context, next) => {

           const membersAdded = context.activity.membersAdded;

           for (let cnt = 0; cnt < membersAdded.length; ++cnt) {

               if (membersAdded[cnt].id !== context.activity.recipient.id) {
            	   
                   await context.sendActivity('Hola, Bienvenido al asistente para tus dudas académicas.!');

               }

           }

           // By calling next() you ensure that the next BotHandler is run.

           await next();

       });

   }

}
	  
module.exports.EchoBot=EchoBot;  
	  


	   

        
	  

