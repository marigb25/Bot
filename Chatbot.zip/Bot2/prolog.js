/**
 * http://usejsdoc.org/
 */
/* jshint esversion: 6 */
 
const spawn = require('child_process').spawn;
 
pname = '/Applications/SWI-Prolog.app/Contents/MacOS/swipl';
console.log(pname);
 
const prolog = spawn(pname, ['-l', 'BD_Correccion.pl']);
 
prolog.stderr.on('data', (data) => {
    console.log(`stderr: ${data}`);
});
 
//data = prolog.stdout.read()
//console.log(`pop:${data}`)
 
prolog.on('close', (code) => {
    console.log(`child process exited with code ${code}`);
});
 
async function doQuery(query) {
     
    console.log(`${query}.\n\n.`);
    prolog.stdin.write(`${query}.\n\n`);
     
    // wait for output starts
    var data = new Promise(function (resolve, reject) {
        setTimeout(function () {
        var d = prolog.stdout.read();
        resolve(d);
    },500);
    });
     
    await data;
     
    console.log(`pop:${data}`)
     
    return data;
     
}
 
function done() {
     
    prolog.stdin.write(`halt.\n\n`);
    // No data return only output
     
}
 
module.exports = {spawn, doQuery, done}